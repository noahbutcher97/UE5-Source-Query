"""
UE5 Source Query Tool - Test Suite

This package contains comprehensive tests for the query tool.
"""

__version__ = "1.0.0"
