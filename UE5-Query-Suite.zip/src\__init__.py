# UE5 Source Query Tool
__version__ = "2.0.0"
__author__ = "Your Name"