"""Core query and extraction functionality"""
from .definition_extractor import DefinitionExtractor, DefinitionResult

__all__ = ['DefinitionExtractor', 'DefinitionResult']